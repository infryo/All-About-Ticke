<?php
require 'filemanager/evconfing.php';
echo $maindata['data'];
