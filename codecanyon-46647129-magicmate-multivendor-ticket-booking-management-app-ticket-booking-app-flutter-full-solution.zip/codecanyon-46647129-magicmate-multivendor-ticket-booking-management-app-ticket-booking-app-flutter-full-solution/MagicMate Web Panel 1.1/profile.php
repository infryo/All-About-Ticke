<?php
   include "filemanager/head.php"; ?>
<!-- loader ends-->
<!-- tap on top starts-->
<div class="tap-top"><i data-feather="chevrons-up"></i></div>
<!-- tap on tap ends-->
<!-- page-wrapper Start-->
<div class="page-wrapper compact-wrapper" id="pageWrapper">
   <!-- Page Header Start-->
   <?php include "filemanager/navbar.php"; ?>
   <!-- Page Header Ends                              -->
   <!-- Page Body Start-->
   <div class="page-body-wrapper">
      <!-- Page Sidebar Start-->
      <?php include "filemanager/sidebar.php"; ?>
      <!-- Page Sidebar Ends-->
      <div class="page-body">
         <div class="container-fluid">
            <div class="page-title">
               <div class="row">
                  <div class="col-6">
                     <h3>
                        Profile Management
                     </h3>
                  </div>
                  <div class="col-6">
                  </div>
               </div>
            </div>
         </div>
         <!-- Container-fluid starts-->
         <div class="container-fluid">
            <div class="row size-column">
               <div class="col-sm-12">
                  <div class="card">
                     <div class="card-body">
                        <?php $admindata = $evmulti->query("SELECT * FROM `admin`")->fetch_assoc(); ?>
                        <form method="post" enctype="multipart/form-data">
                           <div class="form-group mb-3">
                              <label>Username</label>
                              <input type="text" min="1" step="1"
                                class="form-control" name="username" required="" value="<?php echo $admindata[
                                 "username"
                                 ]; ?>">
                              <input type="hidden" name="type" value="edit_profile"/>
                              <input type="hidden" name="id" value="1"/>
                           </div>
                           <div class="form-group mb-3">
                              <label>Password</label>
                              <input type="text" min="1" step="1"
                                class="form-control" name="password" value="<?php echo $admindata[
                                 "password"
                                 ]; ?>" required="">
                           </div>
                           <div class="form-group mb-3">
                              <button type="submit" class="btn btn-primary mb-2">Edit Profile</button>
                           </div>
                     </div>
                     </form> 
                  </div>
               </div>
            </div>
         </div>
         <!-- Container-fluid Ends-->
      </div>
      <!-- footer start-->
   </div>
</div>
<?php include "filemanager/script.php"; ?>
<!-- Plugin used-->
</body>
</html>
